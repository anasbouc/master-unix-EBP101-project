#include <stdio.h> 
#include <math.h> 

int main()
{

	char k;

	scanf("%c", &k);
	printf("%c\n", k);

	scanf("%c", &k);
	printf("%c\n", k);
}

#include <stdio.h> 
#include <math.h> 

int main()
{
	char k;
	char x;
	char y;


	while ((scanf ("%c%c%c", &k, &x, &y) == 3))
	{
		printf("%c%c%c\n", k, x, y);
	} 


}

#include <stdio.h> 
#include <math.h> 

int main()
{

int	 x;
float	 y;

printf("Please Babis enter an integer and a float:\n");

scanf("%d %f", &x , &y);

printf("The value of x is %d\n", x);

printf("The value of y is %f\n", y);

}

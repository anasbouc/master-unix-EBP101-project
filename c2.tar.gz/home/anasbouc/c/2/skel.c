#include <stdio.h> 
#include <math.h> 

int main()
{



}

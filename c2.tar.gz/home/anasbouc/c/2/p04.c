#include <stdio.h> 
#include <math.h> 

int main()
{

	char k;

	while ( (scanf("%c", &k) == 1))
	{

		printf("%c\n", k);

	}


}
